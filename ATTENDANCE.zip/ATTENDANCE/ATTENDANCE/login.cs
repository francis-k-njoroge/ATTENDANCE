﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATTENDANCE
{
    public partial class login : Form
    {
        Conn conn = new Conn();
        public static string Usernames;
        public static string position;
        public login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string inputUsername = textBox1.Text;
                string inputPassword = textBox2.Text;
                Usernames = textBox2.Text;

                conn.OpenCon();
                SqlCommand command = new SqlCommand("SELECT residency FROM tbluser WHERE username=@username AND password=@password", conn.GetCon());
                command.Parameters.AddWithValue("@username", inputUsername);
                command.Parameters.AddWithValue("@password", inputPassword);
                SqlDataReader reader = command.ExecuteReader();



                if (reader.HasRows)
                {

                    reader.Read();
                    string userPosition = reader.GetString(0); // get the user's position from the database
                    position = userPosition;
                    if (userPosition == "admin")
                    {
                        Form2 sg = new Form2();
                        sg.Show();
                        this.Hide();

                    }
                    else if (userPosition == "user")
                    {
                        signlogs sg = new signlogs();
                        sg.Show();
                        this.Hide();

                    }

                   
                    
                    else
                    {
                        MessageBox.Show("Invalid user position."); // show an error message if the user's position is not recognized
                        conn.CloseCon();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid username or password."); // show an error message if the user is not found in the database
                    conn.CloseCon();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    

    }
}
