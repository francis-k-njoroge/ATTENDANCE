﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATTENDANCE
{
    public partial class signlogs : Form
    {
        Conn Conn = new Conn();
        public signlogs()
        {
            InitializeComponent();
        }


        public void userid()
        {
            string user_id;
            string query = "SELECT logid FROM signinlog ORDER BY logid Desc";
            Conn.OpenCon();
            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            SqlDataReader dr = command.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1-1;
                user_id = id.ToString("00");

            }
            else if (Convert.IsDBNull(dr))
            {
                user_id = ("00");
            }
            else
            {
                user_id = ("10");
            }

            textBox5.Text = user_id.ToString();
            Conn.CloseCon();

        }


        public void fill()
        {
            // Get the user id entered in textBox1
            string user_Id = Convert.ToString(textBox1.Text);

            // Set up the database connection and command
            using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\francis\Documents\attendance.mdf;Integrated Security=True;Connect Timeout=30"))
            {
                string query = "select user_id, username, surname, email from tbluser where username = @userId";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    // Add the user id parameter to the command
                    cmd.Parameters.AddWithValue("@userId", user_Id);

                    // Open the connection and execute the query
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Check if the query returned any rows
                    if (reader.HasRows)
                    {
                        // Read the data and display it in the appropriate text boxes
                        reader.Read();
                        textBox2.Text = reader.GetString(1); // username
                        textBox3.Text = reader.GetString(2); // surname
                        textBox4.Text = reader.GetString(3); // email
                    }
                    else
                    {
                        // If no rows were returned, display an error message
                        MessageBox.Show("No user found with id " + user_Id.ToString());
                    }
                }
            }
        }


        private void signlogs_Load(object sender, EventArgs e)
        {
            timer1.Start();
            userid();
            textBox1.Text = login.Usernames;
            fill();
            CheckSign();
            CheckSignout();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            fill();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string insertQuery = "INSERT INTO signinlog  VALUES (" + textBox5.Text + ", '" + textBox1.Text + "','" + textBox2.Text + "','"
                    + textBox4.Text + "','" + label4.Text + "','" + label4.Text + "', 'Success ' ,'no ')"; 
                SqlCommand command = new SqlCommand(insertQuery, Conn.GetCon());
                Conn.OpenCon();
                command.ExecuteNonQuery();
                CheckSign();
                CheckSignout();
                MessageBox.Show("item Added Successfully", "Add Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                userid();
                //clear();
               
                textBox2.Focus();
                Conn.CloseCon();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       

public void CheckSign()
    {
        string query = "select * from signinlog where logid='"+textBox5.Text+"' and user_name ='"+textBox1.Text+ "' and sign_in='success' and sign_out='no' ";

        using (SqlCommand command = new SqlCommand(query, Conn.GetCon()))
        {
            Conn.OpenCon();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                // Disable button1
                button1.Enabled = false;
            }
            else
            {
                // Enable button1
                button1.Enabled = true;
            }

            reader.Close();
        }
    }

        public void CheckSignout()
        {
            string query = "select * from signinlog where logid='" + textBox5.Text + "' and user_name ='" + textBox1.Text + "' and sign_out='yes'";

            using (SqlCommand command = new SqlCommand(query, Conn.GetCon()))
            {
                Conn.OpenCon();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    // Disable button1
                    button2.Enabled = false;
                    button1.Enabled = false;
                }
                else
                {
                    // Enable button1
                    button2.Enabled = true;
                }

                reader.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            label4.Text = DateTime.Now.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string updateQuery = "UPDATE [dbo].[signinlog]  SET [sign_in_time] = '"+ label4.Text+"', [sign_out] = 'yes' WHERE [logid] = '"+textBox5.Text+"' AND [user_id] = '"+textBox1.Text+"';";
            SqlCommand command = new SqlCommand(updateQuery, Conn.GetCon());
            Conn.OpenCon();
            command.ExecuteNonQuery();
            CheckSign();
            CheckSignout();

            MessageBox.Show("Category Updated Successfully");
            Conn.CloseCon();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();

        }
    }
}
