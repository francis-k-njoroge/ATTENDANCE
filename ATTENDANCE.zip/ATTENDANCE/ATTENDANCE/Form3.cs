﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATTENDANCE
{
    public partial class Form3 : Form
    {
        Conn Conn = new Conn();
        public Form3()
        {
            InitializeComponent();
        }
        public void userlog()
        { if (textBox3.Text == "")
            {



                string selectQuerry = "SELECT *, DATEDIFF(second, sign_out_time, sign_in_time) as time_diff FROM signinlog ";

                SqlCommand command = new SqlCommand(selectQuerry, Conn.GetCon());
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        else
            {
                searchat();

            }
                

        }

        public void searchat()
        {

            string selectQuerry = "DECLARE @pattern NVARCHAR(50) = '%" + textBox3.Text + "%' SELECT logid, user_id, user_name, email, sign_in_time, sign_out_time, sign_in, sign_out FROM signinlog WHERE email LIKE @pattern ";

            SqlCommand command = new SqlCommand(selectQuerry, Conn.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }



        private void Form3_Load(object sender, EventArgs e)
        {
            userlog();

        }
      
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            searchat();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form2 ff = new Form2();
            ff.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 ff = new Form1();
            ff.Show();
            this.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            login ff = new login();
            ff.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {
          CLOSESIGN ff = new CLOSESIGN();
            ff.Show();
            this.Hide();
        }
    }
}
