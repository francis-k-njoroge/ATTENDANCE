﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATTENDANCE
{
    public partial class Form2 : Form
    {
        Conn Conn = new Conn();

        public Form2()
        {
            InitializeComponent();
        }

        public void users ()
        {

            string query = "select count(*) from tbluser  ";

            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            Conn.OpenCon();
            int count = (int)command.ExecuteScalar();
            Conn.CloseCon();
            label1.Text = count.ToString();

        }
        public string sd;
        public void lastid()
        {

            string query = " SELECT top 1 logid FROM signinlog ORDER BY logid Desc ";

            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            Conn.OpenCon();
            int count = (int)command.ExecuteScalar();
            Conn.CloseCon();
            sd= count.ToString();

        }


        public void usersin()
        {
            string query = "SELECT COUNT(*) FROM signinlog WHERE sign_out = 'no' AND logid = " + sd;

            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            Conn.OpenCon();
            int count = (int)command.ExecuteScalar();
            Conn.CloseCon();
            label2.Text = count.ToString();
        }



        public void usersout()
        {

            string query = " select count(*) from signinlog where sign_out !='no' ";

            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            Conn.OpenCon();
            int count = (int)command.ExecuteScalar();
            Conn.CloseCon();
            label4.Text = count.ToString();

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lastid();
            users();
            usersin();
            usersout();
            label8.Text = login.Usernames.ToUpper();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form1 F = new Form1();
            F.Show();
            this.Hide();

            
        }
        public void userid()
        {
            
            string query = "SELECT logid FROM signinlog ORDER BY logid Desc";
            Conn.OpenCon();
            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            SqlDataReader dr = command.ExecuteReader();
            
        }
            private void button3_Click(object sender, EventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CLOSESIGN c = new CLOSESIGN();
            c.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 fff = new Form3();
            fff.Show();
            this.Hide();
        }
    }
}
