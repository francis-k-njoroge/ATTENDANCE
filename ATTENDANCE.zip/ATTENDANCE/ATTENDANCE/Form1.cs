﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ATTENDANCE
{
    public partial class Form1 : Form
    {
        Conn Conn = new Conn(); 
        public Form1()
        {
            InitializeComponent();
        }


        public void userid()
        {
            string user_id;
            string query = "SELECT user_id FROM tbluser ORDER BY user_id Desc";
            Conn.OpenCon();
            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            SqlDataReader dr = command.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                user_id = id.ToString("0000");

            }
            else if (Convert.IsDBNull(dr))
            {
                user_id = ("0000");
            }
            else
            {
                user_id = ("1000");
            }

            textBox1.Text = user_id.ToString();
            Conn.CloseCon();

        }

       

            public void get_table_user()
        {
            string selectQuerry = " SELECT* FROM tbluser ";
            SqlCommand command = new SqlCommand(selectQuerry, Conn.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView1.DataSource = table;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            userid();
            get_table_user();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
           
            try
            {
                string insertQuery = "INSERT INTO tbluser  VALUES (" + textBox1.Text + ", '" + textBox2.Text + "','" + textBox3.Text + "','"
                    + textBox4.Text + "','" + textBox5.Text + "','" +comboBox1.Text+ "','" + textBox6.Text + "','" + textBox7.Text + "'," +
                    "'" + textBox8.Text + "','" + dateTimePicker1.Text + "','" + comboBox2.Text + "','" + comboBox2.Text + "'," +
                    "'" + textBox10.Text + "')";
                SqlCommand command = new SqlCommand(insertQuery, Conn.GetCon());
                Conn.OpenCon();
                command.ExecuteNonQuery();
                MessageBox.Show("item Added Successfully", "Add Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                userid();
                //clear();
                get_table_user();
                textBox2.Focus();
                Conn.CloseCon();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void clear()

        {
            userid();
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 ff = new Form1();
            ff.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            CLOSESIGN ff = new CLOSESIGN();
            ff.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 ff = new Form3();
            ff.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            login ff = new login();
            ff.Show();
            this.Hide();
        }
    }
}
