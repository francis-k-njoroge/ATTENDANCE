﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ATTENDANCE
{
    public partial class CLOSESIGN : Form
    {
        Conn Conn = new Conn();
        public CLOSESIGN()
        {
            InitializeComponent();
        }

        public void userid()
        {
            string user_id;
            string query = "SELECT logid FROM signinlog ORDER BY logid Desc";
            Conn.OpenCon();
            SqlCommand command = new SqlCommand(query, Conn.GetCon());
            SqlDataReader dr = command.ExecuteReader();
            if (dr.Read())
            {
                int id = int.Parse(dr[0].ToString()) + 1;
                user_id = id.ToString("00");

            }
            else if (Convert.IsDBNull(dr))
            {
                user_id = ("00");
            }
            else
            {
                user_id = ("10");
            }

            textBox1.Text = user_id.ToString();
            Conn.CloseCon();

        }

        private void CLOSESIGN_Load(object sender, EventArgs e)
        {
            userid();
            timer1.Start();
            prod();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO signinlog  VALUES (" + textBox1.Text + ", 'admin','admin','admin@admin','" + label3.Text + "','" + label3.Text + "', 'CLOSE ' ,' CLOSE')";
            SqlCommand command = new SqlCommand(insertQuery, Conn.GetCon());
            Conn.OpenCon();
            command.ExecuteNonQuery();
            userid();
            prod();
            MessageBox.Show("item ");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            timer1.Start();
            label3.Text = DateTime.Now.ToString();
        }

        public void prod()
        {
            string selectQuerry = "select * from signinlog where logid = (select max(logid) from signinlog) ";

            SqlCommand command = new SqlCommand(selectQuerry, Conn.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dataGridView1.DataSource = table;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string insertQuery = "INSERT INTO signinlog  VALUES (" + textBox1.Text + ", 'admin','admin','admin@admin','" + label3.Text + "','" + label3.Text + "', 'OPEN ' ,' OPEN')";
            SqlCommand command = new SqlCommand(insertQuery, Conn.GetCon());
            Conn.OpenCon();

            command.ExecuteNonQuery();
            userid();
            prod();
            MessageBox.Show("item ");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3();
            f.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
            this.Hide();
        }
    }
}
